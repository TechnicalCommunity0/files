#!/usr/bin/python

import os
import time
import sys

while True:
    os.system("clear")
    os.system("cat /var/www/html/usernames.txt")
    time.sleep(2)
