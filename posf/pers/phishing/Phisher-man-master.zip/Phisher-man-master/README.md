### Phisher-man
best phishing tool ever made for kali linux work with ngrok 
it has morethan 17 different of phishing page (fake page)

### Usage:
```
git clone https://github.com/FDX100/Phisher-man.git
cd Phisher-man
python phisherman.py
```
![sh](https://github.com/FDX100/Phisher-man/blob/master/img/1.png)
![sh](https://github.com/FDX100/Phisher-man/blob/master/img/2.png)
![sh](https://github.com/FDX100/Phisher-man/blob/master/img/3.png)
