# Blue-Thunder-IP-Locator
Retrieve informations about an ip adress or a hostname This tool is scripted in perl as you can tell -_- you can help us by subscribing to our youtube channel :. https://goo.gl/FpAkp5 .: before opening the tool use this command chmod +x blue_thunder_IP_locator.pl its nothing special it just provides information from this website http://ip-api.com/ check it out thanks for using our tool.


# Before using install & Upgrade perl libs

$ apt-get install liblocal-lib-perl

$ apt-get install libjson-perl

$ apt-get upgrade libjson-perl

# How to Use
https://youtu.be/wH8HozCLmHw


# More
💀 Watch More Tools & Videos Here: https://goo.gl/GSLWmp


The Shadow Brokers
