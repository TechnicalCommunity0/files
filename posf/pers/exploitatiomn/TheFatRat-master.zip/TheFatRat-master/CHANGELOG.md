## CHANGELOG
* v1.9.7 - Output folder for all generated files in fatrat will now be in $Home/Fatrat_Generated
* V1.9.7 - Removed dex2jar , proguard , not needed anymore for new backdoor_apk , updated backdoor_apk to 0.2.4a and all tools
* v1.9.7 - APKtool updated to 2.4.0
* v1.9.7 - Version control added to file instead in source code , fixed all pwnwinds backdoor payload options
* v1.9.6 - fixes in pwnwinds and in setup
* v1.9.6 - new features added Trodebi ( Trojan debian package - embed in debian package ) 
* v1.9.6 - updated pwnwinds & add Create Backdoor with C to dll ( custom dll inject )
* v1.9.6 - removed monodevelop in depend ( people have option to instal it , install manual )
* v1.9.5 - 64bit exe option added in powerfull.sh
* v1.9.5 - Fixes in backdoor-factory option
* v1.9.5 - Obfuscation method implemented in powerstager & ability to choose icon for rat EXE in powerstager
* v1.9.5 - Desktop shortcut implemeted in setup
* v1.9.5 - Update Android Build Tools -> R26 & Android Platform -> 26-R01
* v1.9.5 - Update powerstager to 0.2.5
* v1.9.5 - Code missing in fudwin (fixed)
* v1.9.5 - added dll injection attack 
* v1.9.5 - update function () creator script into ver 1.3
* v1.9.4 - Fix in microsploit option 5 , grab script created to get msfconsole generated payload while running
* v1.9.4 - Fatrat will be full terminal mode , Powerstage tool added , Setup script rebuilded
* v1.9.3 - Added update script
* v1.9.3 - Dex2Jar will be installed from now on from Fatrat setup manually on user system (reason: Kali repo still uses old version)
* v1.9.3 - Updated Android build tools to V.26 RC1 & Android Platform V. 25-R03
* v1.9.3 - Updated dana travis backdoor-apk to 0.2.2 into fatrat / added openssl in setup
* v1.9.2 - Msfvenom Android rat will be signed with android certificate , so it can be installed properly
* v1.9.2 - Implemented Default Lhost & Lport config to fatrat & powerfull shell creator
* v1.9.2 - Fixed payload in pnwinds option2
* v1.9.2 - Implemented Stop functions in pnwinds 
* v1.9.2 - New signing process in old method backdoor apk & option to create listener
* v1.9.2 - Implemented possibility for user to save msfconsole listeners
* v1.9.2 - Fixes in Microsploit
* v1.9.2 - Implemented local ip , public ip & hostname display to powerfull.sh
* v1.9.2 - Implemented local ip , public ip & hostname display before user set Lhost
* v1.9.2 - Implemented log creation for microsploit & fixed bugs
* v1.9.2 - Added effective way to detect user linux distribution
* v1.9.2 - Setup.sh ( patched )
* v1.9.2 - bug in microsploit ( patched )
* v1.9.2 - delt some function and variable 
* v1.9.1 - v1.9.1 - Implemented Microsploit (Office Exploitation Tool)
* v1.9b - Implemented Backdoor-apk from Dana James Traversie in this version .{  Less tools to install during setup.sh }
* v1.9.0 - update script setup.sh
* v1.9.0 - del some variable and function
* v1.9.0 - fixed typo and bugs
* v1.9.0 - Backdoor APKS have a new payload hiding method in rat apk to not be detected .
* v1.9.0 - APK (5) rat rebuild totally changed .(adapted backdoor-apk script to fatrat to both work together)
* v1.9.0 - Apktool will not be installed no more by setup.sh , the same thing applies to : dx , zipalign (apktool on debian repo is 2.2.1 , and that version have a bug that gives error on compiling the apks , so , apktool and android tools were updated to latest version 25.0.2 and embeded in (tools) directory of fatrat .

* v1.8.5 - fixed some bugs and double function in setup.sh
* v1.8.1 - added possibility to configure metasploit , backdoor-factory & searchsploit with manual inputs

*  - added more packages instalations needed for non-pentest distribution & some bugs fixed

* v1.8 - add file pumper in TFR
* v1.8 - Backdoor with c program for meterpreter reverse_tcp
* v1.8 - Metasploit staging protocol ( c program )
* v1.8 - add new features andd update pwnwinds 
* v1.8 - add some function
* v1.8 - Fixed bug in fatrat
* v1.7 - add backdoor ( rar files )
* v1.7 - Add backdoor ( doc not macro attack)
* v1.7 - Add new features in optional 1 ( create backdoor with msfvenom )
* v1.7 - Fix any bug 
* v1.6 - Add new features create backdoor with PwnWinds ( FUD++ )
* v1.6 - Add some script for checking monodevelop and apache server
* v1.6 - Add new features backdooring original apk with metasploit
* v1.6 - Add setup.sh for configuration fatrat and install dependencies
* v1.6 - remove auto install bdf and mingw ( funciton checked )
* v1.6 - Add listener for android 
* v1.6 - Add feature for cleanup all backdoor 
* v1.5 - Add featrues embed backdoor with backdoor-factory
* v1.5 - Recoded fucntion cmsfvenom
* v1.5 - add feature exit ( auto stop service apache and metasploit )
* v1.5 - Add some Variables ( pwd , Version ,Codename )
* v1.5 - Added script function gboor ( checked if your command is correct)
* v1.5 - Added script function spinner for randoom seed generator from avoid
* v1.5 - Added script function spinner metasploit generator from avoid
* V1.5 - Added autorun script when create listener
* v1.5 - Remove cd "output"
* v1.5 - Change the script ouput when msfvenom create
* v1.4 - Fixed fatrat ( cd output not found )
* v1.4 - Fixed powerfull.sh
* v1.4 - Fixed fatrat
* v1.4 - Change autorun icons with icon avira
* v1.3 - Fixed Code ( backdoor apk in option 1 )
* v1.2 - Added msfvenom multi encoders option 1 ( for windows ) ( with 5 encoders )
* v1.2 - Added msfvenom multi encodersin optiion 1 ( For Windows ) ( with two encoders )
* V1.2 - Added script automated install gcc in fatrat
* v1.1 - Added New Feature ( Create Backdoor With Avoid )
* v1.1 - Add multi encoder in msfvenom
* v1.1 - Fixed Bug
* v1.0 - Release TheFatRat
