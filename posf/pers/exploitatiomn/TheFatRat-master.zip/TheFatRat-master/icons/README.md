Icons Folder to be used in fatrat backdoor creation
