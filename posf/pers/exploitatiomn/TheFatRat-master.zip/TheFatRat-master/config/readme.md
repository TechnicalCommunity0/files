-----------------------------------------
|Folder for FatRat configuration files .|
|     Do Not Remove this file .         |
-----------------------------------------
