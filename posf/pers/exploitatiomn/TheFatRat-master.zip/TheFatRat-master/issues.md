
# Issue
- When creating a new issue in fatrat github , upload the files according to your issue :


### Packages installation (using setup.sh)
- fatrat creates a log file during the setup that is stored in TheFatRat/logs/install.log
if your issue is related to setup then make sure you upload to your issue in github this file .

### Using fatrat
- Microsploit
fatrat creates a log file during the execution of microsploit in TheFatRat/logs/msploit.log
if your issue is related to microsploit then make sure you upload this file to your issue in github .

### Using Fudwin (powerstager) in fatrat
- fatrat creates a log file during the execution of powerstager in TheFatRat/logs/fudwin.log
if your issue is related to powerstager then make sure you upload this file to your issue in github .

### Using backdoor_apk (creating android files)
- fatrat creates a log file during the execution of backdoor apk in TheFatRat/logs/apk.log
if your issue is related to backdoor apk then make sure you upload this file to your issue in github .

# Upload screenshots
- To upload your log file to your issue click bellow your new created issue text field , like it can be show in the next image :
nissue

<img src="https://user-images.githubusercontent.com/7487321/28249733-719e7fa8-6a29-11e7-9f75-1189f9a18dc9.png" ></img>

# Read  
- If any issue is created in fatrat github related to one of the tools before and if you do not upload what we ask "respective tool log file in fatrat/logs directory (so we can detect the problem more faster) , then we will close automatically your issue without any reply in it .

