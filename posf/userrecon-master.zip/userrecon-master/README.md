# UserRecon v1.0
# Author: @linux_choice
# https://github.com/thelinuxchoice/userrecon

Find usernames across over 75 social networks
This is useful if you are running an investigation to determine the usage of the same username on different social networks.

![ur](https://user-images.githubusercontent.com/34893261/43992221-49d40f1c-9d52-11e8-8f58-24ae4aa11dd6.png)
