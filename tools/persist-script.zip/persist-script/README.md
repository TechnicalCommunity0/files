Download the script.py and run it from the terminal:
> python script.py

or
> python3 script.py

The generation of the script may take some time based on the size of the apk.
Do not delete anything from the "temp" folder which is created when the script is being generated or the software may malfunction.
