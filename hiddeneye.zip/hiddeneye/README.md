<p align="left">
  <a><img title="Built With Love" src="https://forthebadge.com/images/badges/built-with-love.svg" ></a>
 </p>
<p align="center">
  <img src="logo.png">  
</p>

<p align="center">
      Modern Phishing Tool With Advanced Functionality 
</p>
<p align="center">
     PHISHING | KEYLOGGER | INFORMATION_COLLECTOR | ALL_IN_ONE_TOOL | SOCIALENGINEERING  
</p>

<p align="center">
  <a href=""><img title="Open Source Love" src="https://badges.frapsoft.com/os/v3/open-source.svg?v=102" ></a>
  <a href="https://gitlab.com/an0nud4y/HiddenEye/releases"><img title="GitHub version" src="https://d25lcipzij17d.cloudfront.net/badge.svg?id=gh&type=6&v=0.5.3&x2=0" ></a>  
</p>

# AVAILABLE TUNNELLING OPTIONS**
0) LOCALHOST 
1) LOCALXPOSE (https://localxpose.io)
2) SERVEO (https://serveo.net/)
3) NGROK (https://ngrok.com/)
4) LOCALTUNNEL (https://localtunnel.me)
5) OPENPORT (https://openport.io/)
6) PAGEKITE (https://pagekite.net/)

# SCREENSHOT (Android-Userland)
![Shot](https://gitlab.com/An0nUD4Y/hiddeneye/-/raw/master/Screenshot.png)


### TESTED ON FOLLOWING:-
* **Kali Linux - Rolling Edition**
* **Parrot OS - Rolling Edition**
* **Linux Mint - 18.3 Sylvia**
* **Ubuntu - 16.04.3 LTS**
* **MacOS High Sierra**
* **Arch Linux**
* **Manjaro XFCE Edition 17.1.12**
* **Black Arch**
* **Userland App (For Android Users)**
* **Termux App (For Android Users)**


### PREREQUISITES ( Please verify if you have installed )
* Python 3
* PHP
* sudo

# FOUND A BUG ? / HAVE ANY ISSUE ? :- (Read This)
* Check closed & solved issues/bugs before opening new.
* Make sure your issue is related to the codes and resources of this repository.
* Its your responsibility to response on your opened issues.
* If we don't found user response on his/her issue in the particular time interval , Then we have to close that issue.
* Do Not Spam or Advertise & Respect Everyone.

### WHAT'S NEW FEATURES
**1) LIVE ATTACK**
- Now you will have live information about the victims such as : IP ADDRESS, Geolocation, ISP, Country, & many more.

**2) COMPATIBILITY**
- All the sites are mobile compatible.

**3) KEYLOGGER**
- Now you will also have the ability to capture all the keystokes of victim.
- You can now Deploy Keyloggers With (Y/N) option.
- Major issues fixed.

**4) ANDROID SUPPORT**
- We care about Android Users, So now we have came with two ways to run HiddenEye in Android Devices.

**(A) UserLand App**
- You Have to Download UserLand App. [Click Here](https://play.google.com/store/apps/details?id=tech.ula) To Download it.
- To read more how to set up userland app Read <a href="https://null-byte.wonderhowto.com/how-to/android-for-hackers-turn-android-phone-into-hacking-device-without-root-0189649/">HERE</a></p> 

**(B) Termux App**
  - You Have to Download Termux App. [Click Here](https://play.google.com/store/apps/details?id=com.termux) To Download it.
  - For Further instruction [Check Instructions](https://gitlab.com/An0nUD4Y/hiddeneye/-/blob/master/instructions.md)
  - Termux Users Clone With This Command , Unless Errors may occur during Running.
```
git clone -b Termux-Support-Branch https://gitlab.com/an0nud4y/HiddenEye.git

```
**5) NEW LOOK PROVIDED**
- NOW FOCUS EASILY ON TASKS...
- CUSTOMIZE APP WITH YOUR OWN THEMES

**6) SERVEO URL TYPE SELECTION AVAILABLE NOW**
- Major issues with serveo is fixed.
- Now You can choose out of CUSTOM URL and RANDOM URL.

**7) LARGE COLLECTION OF PHISHING PAGES ADDED**
- Pages are taken from various tool including ShellPhish , Blackeye , SocialFish .

**8) CAPTURED DATA BACKUP**
- Backup of Data can be Found At (Server/CapturedData).

**9) EMAIL SUPPORT ADDED**
- Captured Data can be Easily send to Any Email Address (Using Gmail SMTP).
- It Require User's Gmail Username And Password.
- GMAIL 2FA SHOULD BE DISABLED IN ORDER TO USE GMAIL SMTP.
- LESS SECURED APPS SHOULD BE TURNED ON (https://myaccount.google.com/lesssecureapps).

**10) CUSTOM TEMPLATES ADDED**
- Two Extra Custom Templates Added.
- Now Create Your Templates.
- Check Instructions At ( Webpages/CUSTOM/manual.txt )

**11) TOOLS ADDED**

**A) LOCATION (Accurately Locate Smartphones using Social Engineering) (Taken From https://github.com/thewhiteh4t/seeker)**
  - NEAR YOU (By @thewhiteh4t )
  - GDRIVE (By @thewhiteh4t)
## [Check This](https://youtu.be/InSdtLhZzk4) Demonstration video to know How (Location) Social-Engineering-Tool Works.
 
## FOR FURTHER INSTALLATION PROCEDURE - [(CHECK INSTRUCTIONS)](https://gitlab.com/An0nUD4Y/hiddeneye/-/blob/master/instructions.md)

</p>

<h3>Ascii error fix</h3>

 `dpkg-reconfigure locales`

 `Then select: "All locales" Then select "en_US.UTF-8"`

  `After that reboot your machine. Then open terminal and run the command: "locale"`

  `There you will see "en_US.UTF-8" which is the default language. Instead of POSIX.`

## DISCLAIMER
<p align="center">
  TO BE USED FOR EDUCATIONAL PURPOSES ONLY
</p>

The use of the HiddenEye is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program. Please read [LICENSE](LICENSE).




