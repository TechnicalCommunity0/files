gmail_account = "deltahacker000@gmail.com"
gmail_password = "aGFja2luZ2NvbW11bml0eQ=="
recipient_email = "arunpower45@gmail.com"
